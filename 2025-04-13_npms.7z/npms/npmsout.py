# pylint: disable=[missing-module-docstring] # only single class in module
import time
import numpy as np
from esibd.plugins import Device
from esibd.core import Parameter, parameterDict, PluginManager, Channel, PRINT, DeviceController, getTestMode, dynamicImport

########################## NPMS output user interface (lin values) #################################################

def providePlugins():
    """Indicates that this module provides plugins. Returns list of provided plugins."""
    return [NPMSlin, NPMSlog]

class NPMSlin(Device):
    """NPMS output device with a linear scale display. The plugin
    communicates to the NPMS Software via TCP/IP. Each address in the channel
    configuration must be implemented in TCP_Process_Request.vi. The optional
    name address allows to verify channel selections by their corresponding
    names queried from the NPMS Software in the advanced options.
    """

    name = 'NPMS_Lin'
    version = '1.1'
    supportedVersion = '0.7'
    pluginType = PluginManager.TYPE.OUTPUTDEVICE
    unit = ''
    iconFile = 'npms_lin.png'

    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.channelType = NPMSChannel

    def initGUI(self):
        """:meta private:"""
        super().initGUI()
        self.controller = NPMSController(_parent=self)

    def getDefaultSettings(self):
        """:meta private:"""
        defaultSettings = super().getDefaultSettings()
        defaultSettings[f'{self.name}/Hostname'] = parameterDict(value='localhost', toolTip='IP address',
                                                                widgetType=Parameter.TYPE.TEXT, attr='ip')
        defaultSettings[f'{self.name}/Port']     = parameterDict(value=6341, toolTip='port',
                                                                widgetType=Parameter.TYPE.INT, attr='port')
        return defaultSettings

class NPMSChannel(Channel):
    """UI for single voltage channel with integrated functionality"""

    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.lastAppliedValue = None # keep track of last value to identify what has changed

    TYPE   = 'Type'
    NAME_MONITOR  = 'Channel Name'
    NAME_ADDR  = 'Name Address'
    GET_ADDR   = 'Get Value Address'

    def getDefaultChannel(self):
        channel = super().getDefaultChannel()
        channel[self.VALUE][Parameter.HEADER] = 'Value (log)' if self.device.logY else 'Value (lin)' # overwrite to change header
        channel[self.NAME_MONITOR] = parameterDict(value='', widgetType=Parameter.TYPE.TEXT, advanced=True, attr='name_monitor')
        channel[self.NAME_ADDR] = parameterDict(value='', widgetType=Parameter.TYPE.TEXT, advanced=True, attr='name_addr')
        channel[self.GET_ADDR] = parameterDict(value='', widgetType=Parameter.TYPE.TEXT, advanced=True, attr='get_addr')
        return channel

    def setDisplayedParameters(self):
        super().setDisplayedParameters()
        self.insertDisplayedParameter(self.NAME_MONITOR, before=self.COLOR)
        self.insertDisplayedParameter(self.NAME_ADDR, before=self.COLOR)
        self.insertDisplayedParameter(self.GET_ADDR, before=self.COLOR)

    def tempParameters(self):
        return super().tempParameters() + [self.NAME_MONITOR]

class NPMSController(DeviceController): # no channels needed
    # need to inherit from QObject to allow use of signals
    """Implements SCPI communication with ISEG ECH244.
    While this is kept as general as possible, some access to the management and UI parts are required for proper integration."""

    def __init__(self, _parent):
        super().__init__(_parent=_parent)
        self.NPMSclient = dynamicImport('client', self.device.dependencyPath / 'client.py').NPMSclient
        self.client = None

    def runInitialization(self):
        try:
            self.client = self.NPMSclient(connect=False) # after all channels loaded
            self.client.connect()
            self.initialized = True
            self.signalComm.initCompleteSignal.emit()
            # threads cannot be restarted -> make new thread every time. possibly there are cleaner solutions
        except Exception as e: # pylint: disable=[broad-except] # socket does not throw more specific exception
            self.print(f'Could not establish TCP/IP connection to {self.device.ip} on port {self.device.port}. Exception: {e}', PRINT.WARNING)
        finally:
            self.initializing = False

    def initComplete(self):
        self.values = np.zeros(len(self.device.channels)) # default would use NAN
        super().initComplete()
        if not getTestMode():
            for channel in self.device.channels:
                if channel.real and channel.name_addr != '':
                    channel.name_monitor = self.client.get(channel.name_addr)

    def closeCommunication(self):
        if self.client is not None:
            with self.lock.acquire_timeout(1, timeoutMessage='Could not acquire lock before closing client.'):
                self.client.close()
                self.client = None
        super().closeCommunication()

    def runAcquisition(self, acquiring):
        if getTestMode():
            return
        while acquiring():
            with self.lock.acquire_timeout(1) as lock_acquired:
                if lock_acquired:
                    if not getTestMode():
                        for i, channel in enumerate(self.device.channels):
                            if channel.real:
                                if channel.get_addr != '':
                                    self.values[i] = float(self.client.get(channel.get_addr))
                    self.signalComm.updateValuesSignal.emit()
            time.sleep(self.device.interval/1000)
    # TODO delete following if applicable.
    # closeCommunication should be called automatically when needed.
    # Usually I distinguish between stopAquisition (stop recording, but can resume later) and stopCommunication (close all hardware resources)
    # If you want to close the client earlier, extend stopAcquisition
    #     self.afterAcquisition()

    # def afterAcquisition(self):
    #     """close connection to server"""
    #     self.client.close()

class NPMSlog(NPMSlin):
    """NPMS output device with a logarithmic scale display. The plugin
    communicates to the NPMS Software via TCP/IP. Each address in the channel
    configuration must be implemented in TCP_Process_Request.vi. The optional
    name address allows to verify channel selections by their corresponding
    names queried from the NPMS Software in the advanced options.
    """

    name = 'NPMS_Log'
    iconFile = 'npms_log.png'

    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        self.logY = True
