"""
Simple TCP/IP client to communicate with NPMS_Software
"""

import socket
import sys
from typing import Optional

class NPMSclient():
    """
    Simple TCP/IP client to communicate with NPMS_Software

    :Example:
        from npmsroutines import NPMSclient
        client = NPMSclient()
        print(client.get('Options.Save Counter'))
        print(client.set('Options.Save Counter', '0014'))
        client.close()
    """
    def __init__(self, hostname = 'localhost', port = 6341,
                 bufferSize = 1024, connect = True) -> None:
        self._socket : Optional[socket.socket] = None
        self._hostname = hostname
        self._port = port
        self._bufferSize = bufferSize
        if connect:
            self.connect()

    def connect(self) -> None:
        """
        Connect or reconnect to the server
        """
        self.close()
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._socket.connect((self._hostname, self._port))

    def isconnected(self) -> bool:
        """
        Return if there is a connection to server (unreliable)
        """
        return self._socket is not None

    def close(self) -> None:
        """
        Close connection to server
        """
        if self._socket is not None:
            self._socket.close()

    def request(self, message : str) -> str:
        """
        Send a request to NPMS_Software and return the response
        """
        if self._socket is None:
            sys.stderr.write('ERROR: TCP/IP client is not connected')
            return ''
        ident = '0'
        text = f'{ident}:{message}\r\n'.encode()
        self._socket.send(text)
        data = self._socket.recv(self._bufferSize)
        retIdent, *values = data.decode().split(':')
        if retIdent != ident:
            errMsg = f'ERROR: id mismatch (sent {ident}, received {retIdent})'
            sys.stderr.write(errMsg)
        response = ':'.join(values).rstrip('\r\n')
        return response

    def get(self, address : str) -> str:
        """
        Send a get request to NPMS_Software and return the response
        """
        return self.request(f'get:{address}')

    def set(self, address : str, value : str) -> str:
        """
        Send a set request to NPMS_Software and return the response
        """
        return self.request(f'set:{address}:{value}')

    def getHostname(self) -> str:
        """
        Return the hostname
        """
        return self._hostname

    def getPort(self) -> str:
        """
        Return the port
        """
        return self._port

    def setHostname(self, hostname : str) -> None:
        """
        Set the hostname

        To update the connection, connect() needs to be called afterwards.
        """
        self._hostname = hostname

    def setPort(self, port : int) -> None:
        """
        Set the port

        To update the connection, connect() needs to be called afterwards.
        """
        self._port = port
