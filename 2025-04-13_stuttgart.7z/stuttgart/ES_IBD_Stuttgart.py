from ctypes import windll
from esibd.core import Parameter, parameterDict, PluginManager, Channel, dynamicImport #, INOUT, MetaChannel, getDarkMode, MZCalculator
from esibd.plugins import  Device # Scan,

def providePlugins():
    """Indicates that this module provides plugins. Returns list of provided plugins."""
    return [PSU]# AMX

# class MassSpecScan(Scan): # TODO delete and use the internal msScan, If applicable it can be extended to provide backwards compatibility to files generated with MassSpecScan

class PSU(Device):
    # TODO recommend using DeviceController class for consistency and ease of maintanance. See CustomDevice and other internal Devices.
    """Manages the amplitude of multiple digital RF power supplies."""

    name = 'PSU'
    version = '1.1'
    supportedVersion = '0.7'
    iconFile = 'PSU.png'
    pluginType = PluginManager.TYPE.INPUTDEVICE
    unit = 'V'
    useMonitors = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # dynamic import of PSU_Control class
        self.PSU_Control = dynamicImport('PSU_Control', self.dependencyPath / 'PSUcontrol.py').PSU_Control
        self.com = windll.LoadLibrary(str(self.dependencyPath / 'COM-HVPSU2D.dll'))
        self.channelType=PSUChannel
        self._initialized = False

    def getDefaultSettings(self):
        """ Define device specific settings that will be added to the general settings tab.
        These will be included if the settings file is deleted and automatically regenerated.
        Overwrite as needed."""
        defaultSettings = super().getDefaultSettings()
        defaultSettings[self.name + '/Logging'] = parameterDict(value=False, toolTip='Show PSU warnings in console. Only use when debugging to keep console uncluttered.',
                                                   widgetType=Parameter.TYPE.BOOL, attr='log')
        return defaultSettings

    def initializeCommunication(self):
        # overwriting default implementation
        super().initializeCommunication()
        for channel in self.getChannels():
            if channel.enabled:
                channel.initialize()
        self._initialized = True

    def closeCommunication(self):
        # overwriting default implementation
        super().closeCommunication()
        for channel in self.getChannels():
            channel.close()
        self._initialized = False

    def initialized(self):
        # overwriting default implementation
        # super().initialized()
        return self._initialized

class PSUChannel(Channel):
    """UI for single voltage channel with integrated functionality"""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.psu_chn = self.device.PSU_Control(_com=self.device.com, log=self.device.log)

    def initialize(self):
        # TODO this layer of abstraction does not add any functionality, recommend calling functions directly from DeviceController
        """
        called internally (by PSU class) to initialise the psu channel instance
        """
        # if getTestMode():
            # implement test mode for testing without hardware
            # usually done within hardwaremanager but as PSUcontrol.py is made to run standalone, better integration would require to add and maintain an interface class
            # pass
        # else:
        self.psu_chn.initialise (port=self.port,
                                 com_num=self.com,
                                 psu_chn=self.chn,
                                 chn_id=self.name,
                                 enabled=self.enabled)

    def close (self):
        # TODO this layer of abstraction does not add any functionality, recommend calling functions directly from DeviceController
        """
        called automatically by PSU class to close all channels, e.g. when the program is ended
        """
        self.psu_chn.close()

    CURRENT_MAX = 'current_max'
    COM         = 'COM'
    PORT        = 'PORT'
    CHN         = 'CHN'

    def getDefaultChannel(self):
        """Defines parameter(s) to use when generating default file."""
        channel = super().getDefaultChannel()
        channel[self.VALUE][Parameter.HEADER] = 'Voltage (V)' # overwrite to change header
        channel[self.CURRENT_MAX] = parameterDict(value=0, widgetType=Parameter.TYPE.FLOAT, advanced=True,
                                                  attr='current_max', _min=0, _max=1, header='I_max (A)')
        channel[self.COM]   = parameterDict(value=0, widgetType=Parameter.TYPE.INT, advanced=True, _min=0, _max=99, attr='com')
        channel[self.PORT]  = parameterDict(value=0, widgetType=Parameter.TYPE.INT, advanced=True, _min=0, _max=99, attr='port')
        channel[self.CHN]   = parameterDict(value=0, widgetType=Parameter.TYPE.INT, advanced=True, _min=0, _max=1,  attr='chn')
        return channel

    def setDisplayedParameters(self):
        super().setDisplayedParameters()
        self.insertDisplayedParameter(self.COM, before=self.COLOR)
        self.insertDisplayedParameter(self.PORT, before=self.COLOR)
        self.insertDisplayedParameter(self.CHN, before=self.COLOR)
        self.insertDisplayedParameter(self.CURRENT_MAX, before=self.COLOR)

    def applyValue(self, apply): # this actually sets the voltage on the powersupply!
        if self.real and ((self.value != self.lastAppliedValue) or apply):
            #self.device.psuMgr.setVoltage(self)
            self.psu_chn.apply(voltage=self.value, current=self.current_max)
            self.lastAppliedValue = self.value

    def realChanged(self):
        self.getParameterByName(self.COM).getWidget().setVisible(self.real)
        self.getParameterByName(self.PORT).getWidget().setVisible(self.real)
        super().realChanged()

    def enabledChanged(self):
        super().enabledChanged()
        self.psu_chn.set_PSU_enable(enable=self.enabled)
