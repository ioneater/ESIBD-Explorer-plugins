from ctypes import windll
from random import choices

import numpy as np

from esibd.core import PARAMETERTYPE, PLUGINTYPE, PRINT, Channel, DeviceController, Parameter, dynamicImport, parameterDict
from esibd.plugins import Device, Plugin


def providePlugins() -> list['type[Plugin]']:
    """Indicate that this module provides plugins. Returns list of provided plugins."""
    return [PSU]  # AMX


class PSU(Device):
    """Manages the amplitude of multiple digital RF power supplies."""

    name = 'PSU'
    version = '1.2'
    supportedVersion = '0.8'
    iconFile = 'PSU.png'
    pluginType = PLUGINTYPE.INPUTDEVICE
    unit = 'V'
    useMonitors = True
    useOnOffLogic = True

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.channelType = PSUChannel


class PSUChannel(Channel):
    """UI for single voltage channel with integrated functionality."""

    channelParent: PSU
    controller: 'PSUController'

    CURRENT_MAX = 'current_max'
    current_max: float
    COM = 'COM'
    com: int
    PORT = 'PORT'
    port: int
    CHN = 'CHN'
    chn: int

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.controller = PSUController(controllerParent=self)

    def getDefaultChannel(self) -> dict[str, dict]:
        """Define parameter(s) to use when generating default file."""
        channel = super().getDefaultChannel()
        channel[self.VALUE][Parameter.HEADER] = 'Voltage (V)'  # overwrite to change header
        channel[self.CURRENT_MAX] = parameterDict(value=0, parameterType=PARAMETERTYPE.FLOAT, advanced=True,
                                                  attr='current_max', minimum=0, maximum=1, header='I_max (A)')
        channel[self.COM] = parameterDict(value=0, parameterType=PARAMETERTYPE.INT, advanced=True, minimum=0, maximum=99, attr='com')
        channel[self.PORT] = parameterDict(value=0, parameterType=PARAMETERTYPE.INT, advanced=True, minimum=0, maximum=99, attr='port')
        channel[self.CHN] = parameterDict(value=0, parameterType=PARAMETERTYPE.INT, advanced=True, minimum=0, maximum=1, attr='chn')
        return channel

    def setDisplayedParameters(self) -> None:
        super().setDisplayedParameters()
        self.insertDisplayedParameter(self.COM, before=self.COLOR)
        self.insertDisplayedParameter(self.PORT, before=self.COLOR)
        self.insertDisplayedParameter(self.CHN, before=self.COLOR)
        self.insertDisplayedParameter(self.CURRENT_MAX, before=self.COLOR)

    def realChanged(self) -> None:
        self.getParameterByName(self.COM).setVisible(self.real)
        self.getParameterByName(self.PORT).setVisible(self.real)
        super().realChanged()

    def enabledChanged(self) -> None:
        super().enabledChanged()
        if self.channelParent.liveDisplayActive() and self.channelParent.recording:
            if self.enabled:
                self.controller.initializeCommunication()
            elif self.controller.acquiring:
                self.controller.stopAcquisition()


class PSUController(DeviceController):

    controllerParent: PSUChannel

    def __init__(self, controllerParent) -> None:
        super().__init__(controllerParent)
        Modul = dynamicImport('PSU_Control', self.controllerParent.channelParent.dependencyPath / 'PSUcontrol.py')
        if Modul:
            self.PSU_Control = Modul.PSU_Control
        self.psu_chn: self.PSU_Control = None  # type: ignore  # noqa: PGH003

    def runInitialization(self) -> None:
        try:
            self.psu_chn = self.PSU_Control(_com=windll.LoadLibrary(str(self.controllerParent.channelParent.dependencyPath / 'COM-HVPSU2D.dll')),
                                        log=self.controllerParent.channelParent.log)
            self.psu_chn.initialise(port=self.controllerParent.port,
                                 com_num=self.controllerParent.com,
                                 psu_chn=self.controllerParent.chn,
                                 chn_id=self.controllerParent.name,
                                 enabled=self.controllerParent.enabled)
            self.psu_chn.get_PSU_output_voltage()  # trigger error if initialization failed
            self.signalComm.initCompleteSignal.emit()
        except Exception as e:  # pylint: disable=[broad-except]  # socket does not throw more specific exception  # noqa: BLE001
            self.print(f'Could not establish connection at COM {self.controllerParent.com}. Exception: {e}', flag=PRINT.WARNING)
        finally:
            self.initializing = False

    def readNumbers(self) -> None:
        try:
            self.values[0] = self.psu_chn.get_PSU_output_voltage()
        except ValueError as e:
            self.print(f'Error while reading voltage {e}', flag=PRINT.ERROR)
            self.errorCount += 1
            self.values[0] = np.nan

    def fakeNumbers(self) -> None:
        if self.controllerParent.channelParent.isOn() and self.controllerParent.enabled:
            # fake values with noise and 10% channels with offset to simulate defect channel or short
            self.values[0] = self.controllerParent.value + 5 * choices([0, 1], [.98, .02])[0] + self.rng.random() - .5
        else:
            self.values[0] = 0 + 5 * choices([0, 1], [.9, .1])[0] + self.rng.random() - .5

    def applyValue(self, channel: PSUChannel) -> None:
        self.psu_chn.apply(voltage=channel.value, current=channel.current_max)

    def toggleOn(self) -> None:
        super().toggleOn()
        if self.controllerParent.enabled and self.controllerParent.real:
            self.psu_chn.set_PSU_enable(enable=self.controllerParent.channelParent.isOn())
            self.applyValueFromThread(self.controllerParent)

    def closeCommunication(self) -> None:
        super().closeCommunication()
        if self.psu_chn:
            with self.lock.acquire_timeout(1, timeoutMessage='Could not acquire lock before closing.'):
                self.psu_chn.close()
                self.psu_chn = None  # type: ignore  # noqa: PGH003
        self.initialized = False
