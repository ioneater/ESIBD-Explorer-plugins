# -*- coding: utf-8 -*-
"""
@author: alpcan_oenuer, lucie_gerstner, stephan rauschenbach, tim esser
version: 0-4-2
date: 2023-05-08

====
[ ] implement error code for all functions, use table 22
[ ] make sure logging information is only showed if relevant (e.g. in testmode) and clearly identified with this plugin -> prefix messages with self.name
ISSUES

incorrect use of logging function:
see
https://pylint.readthedocs.io/en/latest/user_guide/messages/warning/logging-fstring-interpolation.html
and
https://pylint.readthedocs.io/en/latest/user_guide/messages/convention/unnecessary-dunder-call.html

use pylint in VSCode to spot common mistakes
======

"""
import logging
import os
from ctypes import windll,c_short,byref,c_bool,c_double,c_uint


logging.basicConfig(level = logging.WARNING)
logging.debug('PSU_Control Module')

class PSU_Control():
    """
    Using ctypes and windll to load the libary
    before each function call, the port and respective Com need to be initalized (e.g. Port (7)-> USB Slot,Com(11))
    Variables in the CGC Docs:
        Word -> c_short
        Bool -> c_bool
        double -> c_double
        unsigned -> c_uint
    Usage Example:
        & -> refers to a "Reference" and means an empty Variable with the right type (long, short, bool)
                need to be intialized and in the function a pointer("byref" in ctypes) is to be used
                to refer to the right variable:
                Red = c_bool()
                Green = c_bool()
                Blue = c_bool()
                self.com.COM_HVPSU2D_GetLEDData(c_short(7),byref(Red), byref(Green), byref(Blue))
                print(Red, Green, Blue)
    """

    def __init__(self, _com, log = False):
        self.initialised = False
        self.com = _com
        if not log:
            logging.getLogger().disabled = True
        # TODO all variables should be initialized with default values here

    def initialise (self, port=0, com_num=0, psu_chn=0, chn_id='', enabled=False):
        """
        PARAMETERS
            port_num
            com
            psu_chn = 0 1 ... will be False and True

            IF -> port_num: 10, com_num: 7
            IMF -> port_num: 9, com_num: 12
            Q1 -> port_num: 8, com_num: 9
            QMS -> port_num: 6, com_num: 10
            Q3 -> port_num: 7, com_num: 11
        RETURNS
            n/a
        """
        self.port_num = port
        self.com_num = com_num
        self.psu_chn = psu_chn  # 0 or 1 which physical chn
        self.chn_id = chn_id

        self.open_port()
        self.set_device_enable(enable=True)
        self.set_PSU_enable(enable=enabled)

        self.initialised = True
        # set current max.

    def __str__(self) -> str:
        return f'{self.chn_id}   COM{self.com_num}   port={self.port_num}   psu={self.psu_chn}'

    def out(self) -> str:
        return (f'{self.chn_id}   COM{self.com_num}   port={self.port_num}   psu={self.psu_chn}   enable=(device={self.get_device_enable()},'
                f' channel={self.get_PSU_enable()})   V={self.get_PSU_output_voltage()}V   I={self.get_PSU_output_current()}')

    def open_port(self):
        """
        Opens the communication channel (port_num: USB Slot, com_num: on PSUs)
        and returns an error code according to Tab. 10 in the CGC Manual.
        """
        logging.info('>>> PSU_Control.open_port')
        error_code = self.com.COM_HVPSU2D_Open(c_short(self.port_num),c_short(self.com_num))
        if error_code == 0:
            logging.debug(f"Port {self.port_num} and COM {self.com_num} are initalized")
        elif error_code == -2:
            logging.warning("Port already open.")
        else:
            logging.error(f"Error message {error_code} check table 10 in CGC Manual")

    def close_port (self):
        """
        Closes the communication channel (port_num: USB Slot)
        and returns an error code according to Tab. 10 in the CGC Manual.
        """
        logging.info('>>> PSU_Control.close_port ')

        c = self.com.COM_HVPSU2D_Close(c_short(self.port_num))
        if c == 0:
            logging.debug(f"Port {self.port_num} and Com {self.com_num} are closed")
        elif c == -3:
            logging.warning("Port already closed")
        else:
            logging.error(f"Error message {c} check table 10 in CGC Manual")

    def get_LED_data (self):
        """
        Saves the colors of the LED on the front panel
        in the variables Red, Green, and Blue,
        and returns an error code according to Tab. 10 in the CGC Manual.
        The colors in the variables Red, Green, and Blue are Boolean values,
        i.e. they indicate if each color is turned on or off (True = turned on, False = turned off).
        """
        logging.info('>>> PSU_Control.get_LED_data ')

        Red = c_bool()
        Green = c_bool()
        Blue = c_bool()
        self.com.COM_HVPSU2D_GetLEDData(c_short(self.port_num),byref(Red), byref(Green), byref(Blue))
        logging.info(f"Red: {Red}, Green: {Green}, Blue: {Blue}")

    def get_housekeeping (self):
        """
        int COM_HVPSU2D_GetHousekeeping
            (WORD PortNumber, double & VoltRect,
             double & Volt5V0, double & Volt3V3,
             double & TempCPU);

            Saves the housekeeping data in the variables VoltRect, Volt5V0,
            Volt3V3, and TempCPU, and returns an error code according to
            Tab. 10.
            The return values in the variables VoltRect, Volt5V0, and
            Volt3V3 are supply voltages in V, their nominal values are 10 V,
            5.0 V, and 3.3 V. The return value in the variable TempCPU is the tem-
            perature of the CPU in ºC.
            Note that the return value in the variable VoltRect is the rectified
            voltage supplied by the mains transformer. Its value changes with
            changing mains voltage but the controller works properly as long as it
            is larger than about 6 V.
            The response to the direct command (H©) contains 3 x 4 hexadecimal
            digits for the variables VoltRect (FFFF), Volt5V0 (DDDD), and
            Volt3V3 (CCCC), followed by 4 hexadecimal digits (TTTT) for the
            variable TempCPU. The voltage values are in mV, i.e. in order to con-
            vert them into values in V, they have to be divided by 103. The tem-
            perature variable TempCPU is received in units of 10 mK, i.e. it has to
            be converted by subtracting the offset of 27315 and dividing by 100 to
            get the value in ºC.
        """
        logging.info('>>> PSU_Control.get_housekeeping')
        volt_rects = c_double()
        volt5V0 = c_double()
        volt3V0 = c_double()
        tempCPU = c_double()

        error = self.com.COM_HVPSU2D_GetHousekeeping(c_short(self.port_num),
                                                byref(volt_rects),
                                                byref(volt5V0), byref(volt3V0),
                                                byref(tempCPU))

        logging.info(f'status PSU (COM{self.com_num}, port={self.port_num})')
        logging.info(f'V(rect)={volt_rects.value}V   V(5V)={volt5V0.value}V   V(3V)={volt3V0.value}V   T(CPU)={tempCPU.value}')

        return error

    def get_device_enable (self):
        """
        Saves the enable state (True = Device enabled, False = Device disabled)
        of the device in the variable Enable
        and returns an error code according to Tab. 10 in CGC Manual.
        """
        logging.info('>>> PSU_Control.get_device_enable ')
        enable = c_bool()
        gd = self.com.COM_HVPSU2D_GetDeviceEnable(c_short(self.port_num), byref(enable))
        logging.debug(f"Error Code: {gd}    Device ready: {enable}")
        return enable.value

    def set_device_enable (self, enable=False):
        """
        Sets the enable state for the entire device 9both sources
        (True = Device enabled, False = Device disabled)
        of the device to the value given by the variable Enable
        and returns an error code according to Tab. 10 in the CGC Manual.
        """
        logging.info('>>> PSU_Control.set_device_enable ')
        error = self.com.COM_HVPSU2D_SetDeviceEnable(c_short(self.port_num),
                                                c_bool(enable))
        if error == 0:
            logging.debug(f"\nDevice ready: {enable}")
        else:
            logging.error(f"Error Code: {error}")

    def get_PSU_enable (self):
        """
        Saves the state of the enable flags (True = PSU enabled, False = PSU disabled)
        of the PSU modules in the variables PSU0 and PSU1
        and returns an error code according to Tab. 10 in the CGC Manual.
        """
        logging.info('>>> PSU_Control.get_PSU_enable ')
        psu_0, psu_1 = c_bool(), c_bool()
        error = self.com.COM_HVPSU2D_GetPSUEnable(c_short(self.port_num), byref(psu_0), byref(psu_1))
        psu = psu_1.value if self.psu_chn else psu_0.value
        logging.debug(f" enable {self.__str__()}   enable={psu}   error Code={error}")
        return psu

    def _get_other_PSU_enable (self):
        """
        dont use.  gets the enable state of the other channel.
        ___
        Saves the state of the enable flags (True = PSU enabled, False = PSU disabled)
        of the PSU modules in the variables PSU0 and PSU1
        and returns an error code according to Tab. 10 in the CGC Manual.
        """
        logging.info('>>> PSU_Control._get_other_PSU_enable ')

        psu_0, psu_1 = c_bool(), c_bool()
        error = self.com.COM_HVPSU2D_GetPSUEnable(c_short(self.port_num), byref(psu_0), byref(psu_1))
        psu = psu_0.value if self.psu_chn else psu_1.value
        logging.debug(f" other PSU enable {self.__str__()}   enable={psu}   error Code={error}")
        return psu

    def set_PSU_enable (self, enable=False):
        """
        Sets the enable flags (True = PSU enabled, False = PSU disabled)
        of the PSU modules to the values given by the variables PSU0  and  PSU1
        and  returns  an  error  code  according  to  Tab. 10 in the CGC Manual.
        """
        if self.initialised:
            logging.info('>>> PSU_Control.set_PSU_enable ')
            if self.psu_chn:
                psu_0 = c_bool(self._get_other_PSU_enable())
                psu_1 = c_bool(enable)
            else:
                psu_0 = c_bool(enable)
                psu_1 = c_bool(self._get_other_PSU_enable())
            error = self.com.COM_HVPSU2D_SetPSUEnable(c_short(self.port_num), psu_0, psu_1)
            logging.debug(f" PSU enable {self.__str__()}   error Code={error}")

    def get_enable_state (self):
        device_enable = self.get_device_enable()
        channel_enable = self.get_PSU_enable()
        logging.info(f'{self.__str__()} device enable={device_enable}   channel enable={channel_enable}')
        return device_enable, channel_enable

    def get_PSU_output_voltage(self):
        """
        Saves the output voltage (in V) of the PSU module with the number PSU
        in the variable Voltage
        and returns an error code according to Tab. 10 in the CGC Manual.
        The variable PSU is the number of the PSU module.
        It can be 0 (constant COM_HVPSU2D_PSU_POS in the declaration file COM-HVPSU2D.h)
        or 1 (constant COM_HVPSU2D_PSU_NEG).
        """
        logging.info('>>> PSU_Control.get_PSU_output_voltage ')

        voltage = c_double()
        error = self.com.COM_HVPSU2D_GetPSUOutputVoltage(c_short(self.port_num), c_uint(self.psu_chn), byref(voltage))
        logging.info(f"{self.__str__()}   Error Code: {error}   Output Voltage: {voltage.value}V    ")
        return voltage.value

    def set_PSU_output_voltage (self, voltage=0):
        """
        Sets the output voltage (PSU modules: 0 and 1, Voltage in V)
        of the PSU module with the number PSU to the value in the variable Voltage
        and returns an error code according to Tab. 10 in the CGC Manual.
        """
        logging.info('>>> PSU.Control.set_PSU_output_voltage ')

        error = self.com.COM_HVPSU2D_SetPSUOutputVoltage(c_short(self.port_num), c_uint(self.psu_chn),
                                                    c_double(voltage))
        logging.info(f"{self.__str__()}   Applied Voltage: {voltage} V Error: {error}")

    def get_PSU_output_current (self):
        """
        Saves the output current of the PSU module (0 or 1) with the number PSU
        in the variable Current and returns an error code according to Tab. 10 in the CGC Manual.
        The return value in the variable Current is the value of the output current in A
        that was previously set by the function COM_HVPSU2D_SetPSUOutputCurrent..
        """
        logging.info('>>> PSU.Control.get_PSU_output_current ')

        current = c_double()
        error = self.com.COM_HVPSU2D_GetPSUOutputCurrent(c_short(self.port_num), c_uint(self.psu_chn), byref(current))
        logging.info(f"{self.__str__()}   Error Code: {error}   Output Current: {current.value}A")
        return current.value


    def set_PSU_output_current(self, current=0):
        """
        Sets the output current (PSU modules: 0 and 1, Current in A)
        of the PSU module with the number PSU to the value in the variable Current
        and returns an error code according to Tab. 10 in the CGC Manual.
        """
        logging.info('>>> PSU.Control.set_PSU_output_current()')

        error =  self.com.COM_HVPSU2D_SetPSUOutputCurrent(c_short(self.port_num), c_uint(self.psu_chn),
                                                     c_double(current))
        logging.info(f"{self.__str__()}   Error code={error}   set current={current} A")


    def set_PSU_output_voltage_current(self, voltage_0, current_0, voltage_1, current_1):
        """
        Shortcut function to output for one PSU module: voltage and current.
        Opens the port.
        Sets the output voltage for PSU0 and PSU1
        to the value in the variable Voltage0 and Voltage1.
        Sets the output current for PSU0 and PSU1
        to the value in the variable Current0 and Current1.
        Closes the port.
        """
        logging.info(">>> PSU_Control.set_PSU_output_voltage_current")

        self.open_port()
        self.voltage_0 = voltage_0
        self.voltage_1 = voltage_1
        self.current_0 = current_0
        self.current_1 = current_1

        #set PSU output voltage and current for PSU 0
        self.com.COM_HVPSU2D_SetPSUOutputVoltage(c_short(self.port_num), c_uint(0), c_double(self.voltage_0))
        self.com.COM_HVPSU2D_SetPSUOutputCurrent(c_short(self.port_num), c_uint(0), c_double(self.current_0))
        logging.debug(f"PSU 0\nApplied Voltage: {self.voltage_0}\nApplied Current: {self.current_0}\n")

        #set PSU output coltage and current for PSU 1
        self.com.COM_HVPSU2D_SetPSUOutputVoltage(c_short(self.port_num), c_uint(1), c_double(self.voltage_1))
        self.com.COM_HVPSU2D_SetPSUOutputCurrent(c_short(self.port_num), c_uint(1), c_double(self.current_1))
        logging.debug(f"PSU 1\nApplied Voltage: {self.voltage_1}\nApplied Current: {self.current_1}\n")

        self.close_port()

    def config_on (self):
        """
        Shortcut function to turn on one PSU
        Config4 = PSUs on (Active configurations: KL4)
        1. opens port
        2. enables device
        3. enables PSU
        4. closes port
        """
        logging.info(">>> PSU_Control.config_on")

        self.open_port()
        self.set_device_enable(True)
        self.set_PSU_enable(True)
        self.close_port()



    def config_standby (self):
        """
        Config1 = PSUs standby (Active configurations: KL1)
        1. opens port
        If there is still a current applied, it is set to zero (for both PSU modules(0 and 1)),
        before disabling the PSU and device.
        If there is still a voltage applied, it is set to zero (for both PSU modules (0 and 1)),
        before disabling the PSU and device.
        2. disables PSU
        3. disables device
        4. closes port
        """
        logging.info(">>> PSU_Control.config_standby")
        self.open_port()
        self.com.COM_HVPSU2D_SetPSUOutputCurrent(c_short(self.port_num), c_uint(0), c_double(0))
        self.com.COM_HVPSU2D_SetPSUOutputCurrent(c_short(self.port_num), c_uint(1), c_double(0))
        self.com.COM_HVPSU2D_SetPSUOutputVoltage(c_short(self.port_num), c_uint(0), c_double(0))
        self.com.COM_HVPSU2D_SetPSUOutputVoltage(c_short(self.port_num), c_uint(1), c_double(0))
        self.set_PSU_enable(False)
        self.set_device_enable(False)
        self.close_port()

    def apply (self, voltage=0, current=0):
        """
        set current limit and apply voltage
        """
        if self.initialised:
            self.set_PSU_output_current(current=current)
            self.set_PSU_output_voltage(voltage=voltage)

    def close (self):
        if self.initialised:
            self.initialised=False
            self.set_PSU_enable(enable=False)
            self.set_device_enable(enable=False)
            self.close_port()
            print("close PSU")

if __name__ == '__main__':
    print(__name__)
    COM_1, COM_2, COM_3, COM_4, COM_5, COM_6, COM_7, COM_8, COM_9, COM_10 = 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
    COM_11, COM_12, COM_13, COM_14, COM_15, COM_16, COM_17, COM_18, COM_19, COM_20 = 11, 12, 13, 14, 15, 16, 17, 18, 19, 20

    os.system('cls' if os.name=='nt' else 'clear')
    
    com = windll.LoadLibrary('COM-HVPSU2D.dll')
    
    print('\n   - - - initialisation - - -  \n')
    PSUcontrol_IF_0 = PSU_Control(com)
    PSUcontrol_IF_0.initialise(port=7, com_num=COM_7, psu_chn=0, chn_id="IF-")
    PSUcontrol_IF_1 = PSU_Control(com)
    PSUcontrol_IF_1.initialise(port=7, com_num=COM_7, psu_chn=1, chn_id="IF+")
    PSUcontrol_IF_0.open_port()
    PSUcontrol_IF_1.open_port()

    print(PSUcontrol_IF_0)
    print(PSUcontrol_IF_1)

    print('\n   - - - enable/disable device- - - \n')

    PSUcontrol_IF_0.set_device_enable(enable=True)
    PSUcontrol_IF_1.set_device_enable(enable=True)
    print()

    print('\n   - - - enable/disable channel- - - \n')

    PSUcontrol_IF_0.set_PSU_enable(enable=True)
    PSUcontrol_IF_1.set_PSU_enable(enable=True)
    print()

    PSUcontrol_IF_0.get_enable_state()
    PSUcontrol_IF_1.get_enable_state()
    print()

    print('\n   - - - voltage apply - - - \n')

    v0 = PSUcontrol_IF_0.get_PSU_output_voltage()
    v1 = PSUcontrol_IF_1.get_PSU_output_voltage()
    print(v0, v1)
    i0 = PSUcontrol_IF_0.get_PSU_output_current()
    i1 = PSUcontrol_IF_1.get_PSU_output_current()
    print(i0, i1)

    PSUcontrol_IF_0.set_PSU_output_current(current=1)
    PSUcontrol_IF_1.set_PSU_output_current(current=1)

    PSUcontrol_IF_0.set_PSU_output_voltage(voltage=10)
    PSUcontrol_IF_1.set_PSU_output_voltage(voltage=20)
    print()

    v0 = PSUcontrol_IF_0.get_PSU_output_voltage()
    v1 = PSUcontrol_IF_1.get_PSU_output_voltage()
    print(v0, v1)
    i0 = PSUcontrol_IF_0.get_PSU_output_current()
    i1 = PSUcontrol_IF_1.get_PSU_output_current()
    print(i0, i1)

    print(PSUcontrol_IF_0.out())
    print(PSUcontrol_IF_1.out())

    print('\n   - - - closing - - - \n')

    PSUcontrol_IF_0.set_PSU_enable(enable=False)
    PSUcontrol_IF_1.set_PSU_enable(enable=False)
    print()

    PSUcontrol_IF_0.set_device_enable(enable=False)
    PSUcontrol_IF_1.set_device_enable(enable=False)
    print()

    PSUcontrol_IF_0.get_enable_state()
    PSUcontrol_IF_1.get_enable_state()
    print()

    PSUcontrol_IF_0.close_port()
    print(' ')
    PSUcontrol_IF_1.close_port()
    print(' ')
